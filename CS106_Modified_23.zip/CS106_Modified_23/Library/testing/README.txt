Incorporate SimpleTest into cs106 library as of Fall quarter 2022
(code now pretty stable, possible to patch/shadow on per-project basis as needed)

Fall 2022: very minor changes from last year
(fp equality re: inf/nan, no d suffix on pretty print double)

